﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineQuiz.Models
{
    public class EmployeeQuizModel
    {
        [Required(ErrorMessage = "Quiz Name is Required")]
        [Display(Name = "Quiz Name")]
        [Remote("IsQuizNameAvailable", "Teacher", ErrorMessage = "Quiz Name Already Exists")]
        public string QuizName { get; set; }

        [Required(ErrorMessage = "Topic Name is Required")]
        [Display(Name = "Topic")]
        public string Topic { get; set; }
    }
}
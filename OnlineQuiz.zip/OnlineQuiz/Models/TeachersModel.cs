﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineQuiz.Models
{
    public class TeachersModel
    {
        [Required(ErrorMessage = "Employee Number is Required")]
        [Display(Name = "Employee Number")]
        [RegularExpression(@"^(?=.*\d).{1,8}$", ErrorMessage = "Maximum 8 Characters Are Allowed")]
        [Remote("IsEmployeeNumberAvailable","Teacher",ErrorMessage = "Employee Number Already Exists")]
        public long Eno { get; set; }

        [Required(ErrorMessage = "Name is Required")]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Password is Required")]
        [Display(Name = "Password")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$", ErrorMessage = "Password is not strong")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
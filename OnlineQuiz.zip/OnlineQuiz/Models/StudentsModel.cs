﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OnlineQuiz.Models
{
    public class StudentsModel
    {
        [Required(ErrorMessage = "Roll Number is Required")]
        [Display(Name = "Roll Number")]
        [RegularExpression(@"^(?=.*\d).{1,8}$", ErrorMessage = "Maximum 8 Characters Are Allowed")]
        [Remote("IsRollNumberAvailable", "Student", ErrorMessage = "Roll Number Already Exists")]
        public long Rno { get; set; }

        [Required(ErrorMessage = "Name is Required")]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Password is Required")]
        [Display(Name = "Password")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^\da-zA-Z]).{8,15}$", ErrorMessage = "Password is not strong")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
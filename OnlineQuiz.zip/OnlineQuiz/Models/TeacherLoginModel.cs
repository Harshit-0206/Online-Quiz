﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineQuiz.Models
{
    public class TeacherLoginModel
    {
        [Required(ErrorMessage = "Employee Number is Required")]
        [Display(Name = "Employee Number")]
        [RegularExpression(@"^(?=.*\d).{1,8}$", ErrorMessage = "Maximum 8 Characters Are Allowed")]
        public long Eno { get; set; }

        [Required(ErrorMessage = "Password is Required")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
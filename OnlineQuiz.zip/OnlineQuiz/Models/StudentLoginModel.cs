﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineQuiz.Models
{
    public class StudentLoginModel
    {
        [Required(ErrorMessage = "Roll Number is Required")]
        [Display(Name = "Roll Number")]
        [RegularExpression(@"^(?=.*\d).{1,8}$", ErrorMessage = "Maximum 8 Characters Are Allowed")]
        public long Rno { get; set; }

        [Required(ErrorMessage = "Password is Required")]
        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
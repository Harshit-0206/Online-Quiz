﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace OnlineQuiz.Models
{
    public class QuestionModel
    {
        [Required(ErrorMessage = "Question is Required")]
        [Display(Name = "Question")]
        public string Question { get; set; }

        [Required(ErrorMessage = "Option is Required")]
        [Display(Name = "Option 1")]
        public string OptionA { get; set; }

        [Required(ErrorMessage = "Option is Required")]
        [Display(Name = "Option 2")]
        public string OptionB { get; set; }

        [Required(ErrorMessage = "Option is Required")]
        [Display(Name = "Option 3")]
        public string OptionC { get; set; }

        [Required(ErrorMessage = "Option is Required")]
        [Display(Name = "Option 4")]
        public string OptionD { get; set; }

        [Required(ErrorMessage = "Correct Option is Required")]
        [Display(Name = "Correct Option")]
        public string Correct { get; set; }
    }
}
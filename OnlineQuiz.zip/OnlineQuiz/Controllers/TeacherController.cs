﻿using OnlineQuiz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace OnlineQuiz.Controllers
{
    public class TeacherController : Controller
    {
        private OnlineQuizEntities dbEntities = new OnlineQuizEntities();
        
        public ActionResult Home()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            long usr = long.Parse(User.Identity.Name);
            if (!dbEntities.teachers.Any(u => u.eno == usr))
            {
                FormsAuthentication.SignOut();
                return RedirectToAction("Login");
            }

            ViewBag.Name = dbEntities.teachers.Where(u => u.eno == usr).Select(u => u.name).FirstOrDefault();
            IEnumerable<string> topics = dbEntities.emp_quiz.Select(u => u.topic).Distinct();
            ViewBag.Topics = topics;
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(TeachersModel tModel)
        {
            teacher model = new teacher();
            if (ModelState.IsValid)
            {
                model.eno = tModel.Eno;
                model.name = tModel.Name;
                model.password = tModel.Password;

                dbEntities.teachers.Add(model);
                dbEntities.SaveChanges();
            }
            return RedirectToAction("Login");
        }

        public JsonResult IsEmployeeNumberAvailable(int Eno)
        {
            return Json(!dbEntities.teachers.Any(u => u.eno == Eno), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(TeacherLoginModel model)
        {
            bool isValid = dbEntities.teachers.Any(u => u.eno == model.Eno && u.password == model.Password);
            if (isValid)
            {

                FormsAuthentication.SetAuthCookie(model.Eno.ToString(), false);
                return RedirectToAction("Home");
            }

            ModelState.AddModelError("", "Invalid Employee Number/Password!");
            return View();
        }

        [HttpPost]
        public ActionResult CreateQuiz(EmployeeQuizModel eModel)
        {
            emp_quiz model = new emp_quiz();
            string qname = eModel.QuizName.Trim();
            string topic = eModel.Topic.Trim();
            char[] separators = new char[] { '/', '\\'};
            foreach (char c in separators)
            {
                qname = qname.Replace(c, '|');
                topic = topic.Replace(c, '|');
            }
            model.quizname = qname;
            model.topic = topic;
            model.eno = long.Parse(User.Identity.Name);
            model.avail = 1;

            dbEntities.emp_quiz.Add(model);
            dbEntities.SaveChanges();
            
            TempData["QName"] = qname;
            TempData["QNumber"] = 1;
            return RedirectToAction("AddQuestion");
        }

        public JsonResult IsQuizNameAvailable(string QuizName)
        {
            return Json(!dbEntities.emp_quiz.Any(u => u.quizname == QuizName), JsonRequestBehavior.AllowGet);
        }

        public ActionResult AddQuestion()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            ViewBag.QName = TempData["QName"].ToString();
            ViewBag.QNumber = int.Parse(TempData["QNumber"].ToString());
            return View();
        }

        [HttpPost]
        public ActionResult AddQuestion(QuestionModel qModel, string qName, int qNumber)
        {
            quiz_questions model = new quiz_questions();
            if (ModelState.IsValid)
            {
                model.quizname = qName;
                model.question = qModel.Question;
                model.optionA = qModel.OptionA;
                model.optionB = qModel.OptionB;
                model.optionC = qModel.OptionC;
                model.optionD = qModel.OptionD;

                if (qModel.Correct.Equals("Option 1"))
                {
                    model.correct = qModel.OptionA;
                }
                if (qModel.Correct.Equals("Option 2"))
                {
                    model.correct = qModel.OptionB;
                }
                if (qModel.Correct.Equals("Option 3"))
                {
                    model.correct = qModel.OptionC;
                }
                if (qModel.Correct.Equals("Option 4"))
                {
                    model.correct = qModel.OptionD;
                }

                dbEntities.quiz_questions.Add(model);
                dbEntities.SaveChanges();
            }
            ModelState.Clear();

            ViewBag.QName = qName;
            ViewBag.QNumber = qNumber + 1;
            return View();
        }

        [HttpPost]
        public ActionResult Submit(QuestionModel qModel, string qName, int qNumber)
        {
            quiz_questions model = new quiz_questions();
            if (ModelState.IsValid)
            {
                model.quizname = qName;
                model.question = qModel.Question;
                model.optionA = qModel.OptionA;
                model.optionB = qModel.OptionB;
                model.optionC = qModel.OptionC;
                model.optionD = qModel.OptionD;
                if (qModel.Correct.Equals("Option 1"))
                {
                    model.correct = qModel.OptionA;
                }
                if (qModel.Correct.Equals("Option 2"))
                {
                    model.correct = qModel.OptionB;
                }
                if (qModel.Correct.Equals("Option 3"))
                {
                    model.correct = qModel.OptionC;
                }
                if (qModel.Correct.Equals("Option 4"))
                {
                    model.correct = qModel.OptionD;
                }

                dbEntities.quiz_questions.Add(model);
                dbEntities.SaveChanges();
            }

            return RedirectToAction("Home");
        }

        public ActionResult SeeScores()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            long eno = long.Parse(User.Identity.Name);
            IEnumerable<string> quizes = dbEntities.emp_quiz.Where(u => u.eno == eno ).Select(u => u.quizname);
            ViewBag.Count = 0;
            foreach (string quiz in quizes)
            {
                ViewBag.Count += 1;
            }
            return View(quizes);
        }
        
        public ActionResult SeeScoresByQuizName(string name)
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            IEnumerable<quiz_scores> scores = dbEntities.quiz_scores.Where(x => x.quizname == name).OrderBy(u => u.rno);
            ViewBag.Count = 0;
            foreach (quiz_scores score in scores)
            {
                ViewBag.Count += 1;
            }
            ViewBag.QName = name;

            return View(scores);
        }

        public ActionResult EnableQuiz()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            long eno = long.Parse(User.Identity.Name);
            IEnumerable<string> quizes = dbEntities.emp_quiz.Where(u => u.eno == eno && u.avail == 0).Select(u => u.quizname);
            ViewBag.Count = 0;
            foreach (string quiz in quizes)
            {
                ViewBag.Count += 1;
            }
            return View(quizes);
        }

        [HttpPost]
        public ActionResult EnableQuiz(string quiz)
        {
            long eno = long.Parse(User.Identity.Name);
            var quizRow = dbEntities.emp_quiz.SingleOrDefault(u => u.quizname == quiz);
            quizRow.avail = 1;
            dbEntities.SaveChanges();
            return RedirectToAction("EnableQuiz");
        }

        public ActionResult DisableQuiz()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            long eno = long.Parse(User.Identity.Name);
            IEnumerable<string> quizes = dbEntities.emp_quiz.Where(u => u.eno == eno && u.avail == 1).Select(u => u.quizname);
            ViewBag.Count = 0;
            foreach (string quiz in quizes)
            {
                ViewBag.Count += 1;
            }
            return View(quizes);
        }

        [HttpPost]
        public ActionResult DisableQuiz(string quiz)
        {
            long eno = long.Parse(User.Identity.Name);
            var quizRow = dbEntities.emp_quiz.SingleOrDefault(u => u.quizname == quiz);
            quizRow.avail = 0;
            dbEntities.SaveChanges();
            return RedirectToAction("DisableQuiz");
        }
    }
}
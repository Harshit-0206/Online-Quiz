﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using OnlineQuiz.Models;

namespace OnlineQuiz.Controllers
{
    public class HomeController : Controller
    {
        private OnlineQuizEntities dbEntities = new OnlineQuizEntities();

        public ActionResult Index()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return View();
            }

            long name = long.Parse(User.Identity.Name);
            if (dbEntities.students.Any(u => u.rno == name))
            {
                return RedirectToAction("Home", "Student");
            }
            if (dbEntities.teachers.Any(u => u.eno == name))
            {
                return RedirectToAction("Home", "Teacher");
            }
            return View();
        }

        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index");
        }
    }
}
﻿using OnlineQuiz.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace OnlineQuiz.Controllers
{
    public class StudentController : Controller
    {
        private OnlineQuizEntities dbEntities = new OnlineQuizEntities();

        public ActionResult Home()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            long usr = long.Parse(User.Identity.Name);
            if (!dbEntities.students.Any(u => u.rno == usr))
            {
                FormsAuthentication.SignOut();
                return RedirectToAction("Login");
            }


            if (dbEntities.quiz_scores.Any(u => u.rno == usr))
            {
                IEnumerable<quiz_scores> scores = dbEntities.quiz_scores.Where(u => u.rno == usr);
                ViewBag.Available = true;
                ViewBag.Name = dbEntities.students.Where(u => u.rno == usr).Select(u => u.name).FirstOrDefault();
                return View(scores);
            }

            ViewBag.Available = false;
            ViewBag.Name = dbEntities.students.Where(u => u.rno == usr).Select(u => u.name).FirstOrDefault();
            return View();
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(StudentsModel sModel)
        {
            student model = new student();
            if (ModelState.IsValid)
            {
                model.rno = sModel.Rno;
                model.name = sModel.Name;
                model.password = sModel.Password;

                dbEntities.students.Add(model);
                dbEntities.SaveChanges();
            }
            return RedirectToAction("Login");
        }

        public JsonResult IsRollNumberAvailable(int Rno)
        {
            return Json(!dbEntities.students.Any(u => u.rno == Rno), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(StudentLoginModel model)
        {
            bool isValid = dbEntities.students.Any(u => u.rno == model.Rno && u.password == model.Password);
            if (isValid)
            {

                FormsAuthentication.SetAuthCookie(model.Rno.ToString(), false);
                return RedirectToAction("Home");
            }

            ModelState.AddModelError("", "Invalid Roll Number/Password!");
            return View();
        }

        public ActionResult Topics()
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            IEnumerable<string> topics = dbEntities.emp_quiz.Select(u => u.topic).Distinct();
            ViewBag.Count = 0;
            foreach (string topic in topics)
            {
                ViewBag.Count += 1;
            }
            return View(topics);
        }

        public ActionResult Quizes(string name)
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            IEnumerable<string> quizes = dbEntities.emp_quiz.Where(u => u.topic == name && u.avail ==1).Select(u => u.quizname);
            ViewBag.Count = 0;
            foreach (string quiz in quizes)
            {
                ViewBag.Count += 1;
            }
            return View(quizes);
        }
        
        public ActionResult TakeQuiz(string name)
        {
            if (!User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Login");
            }

            long rno = long.Parse(User.Identity.Name);
            if (dbEntities.quiz_scores.Any(u => u.rno == rno && u.quizname == name))
            {
                quiz_scores qs = dbEntities.quiz_scores.SingleOrDefault(u => u.rno == rno && u.quizname == name);
                ViewBag.Attempted = true;
                ViewBag.Obtained = qs.score;
                ViewBag.Total = qs.total;
                ViewBag.Datetime = "Finished : " + qs.dt.ToString();
                ViewBag.Review = "Not Allowed";
            }
            if (!dbEntities.quiz_scores.Any(u => u.rno == rno && u.quizname == name))
            {
                ViewBag.Attempted = false;
                ViewBag.Obtained = "-";
                ViewBag.Total = dbEntities.quiz_questions.Where(u => u.quizname == name).Count();
                ViewBag.Datetime = "Pending";
                ViewBag.Review = "Allowed";
            }
            ViewBag.QName = name;
            long emp_no = dbEntities.emp_quiz.Where(u => u.quizname == name).Select(u => u.eno).FirstOrDefault();
            ViewBag.Teacher = dbEntities.teachers.Where(u => u.eno == emp_no).Select(u => u.name).FirstOrDefault();
            return View();
        }

        [HttpPost]
        public ActionResult AttemptQuiz(string quiz)
        {
            List<quiz_questions> questions = dbEntities.quiz_questions.Where(u => u.quizname == quiz).Select(u => u).ToList();
            ViewBag.Count = 0;
            foreach (quiz_questions ques in questions)
            {
                ViewBag.Count += 1;
            }
            ViewBag.QName = quiz;
            long emp_no = dbEntities.emp_quiz.Where(u => u.quizname == quiz).Select(u => u.eno).FirstOrDefault();
            ViewBag.Teacher = dbEntities.teachers.Where(u => u.eno == emp_no).Select(u => u.name).FirstOrDefault();

            return View(questions);
        }

        [HttpPost]
        public ActionResult SubmitAnswers(int score, string quiz)
        {
            long rno = long.Parse(User.Identity.Name);
            if (dbEntities.quiz_scores.Any(u => u.rno == rno && u.quizname == quiz))
            {
                ViewBag.QName = quiz;
                return View();
            }
            quiz_scores model = new quiz_scores();
            model.quizname = quiz;
            model.rno = rno;
            model.name = dbEntities.students.Where(u => u.rno == rno).Select(u => u.name).FirstOrDefault();
            model.score = score;
            model.total = dbEntities.quiz_questions.Where(u => u.quizname == quiz).Count();
            model.dt = DateTime.Now;

            dbEntities.quiz_scores.Add(model);
            dbEntities.SaveChanges();

            ViewBag.QName = quiz;
            return View();
        }
    }
}